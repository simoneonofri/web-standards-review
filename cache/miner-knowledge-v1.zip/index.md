# Web Standards Review — offline question index

Candidate questions only. Not W3C consensus, target findings or verified controls.
Publication requires a separate rights review.

| Domain | Records |
|---|---:|
| accessibility | 1 |
| design | 41 |
| harms | 1 |
| human-rights | 1 |
| internationalization | 1 |
| privacy | 38 |
| security | 204 |

For edits, submit a pull request changing cache/curation/overrides.csv.

## accessibility

| Question | Source |
|---|---|
| Which accessibility requirements and risks apply to this feature? | local catalog |

## design

| Question | Source |
|---|---|
| How does the feature expose semantics to assistive technology? | local catalog |
| Are direction, locale, and user preferences respected? | local catalog |
| When does the promise resolve or reject? | local catalog |
| Can callers observe partial completion or retries? | local catalog |
| Can the caller cancel? | local catalog |
| What happens to prompts, streams, and side effects after abort? | local catalog |
| Are deliverables and non-goals concrete? | local catalog |
| Are architectural dependencies and coordination groups identified? | local catalog |
| Is the timeline plausible for the stated scope? | local catalog |
| What user need does the feature serve? | local catalog |
| Why is a web-platform solution needed instead of an application convention? | local catalog |
| Can an unfamiliar technical reader understand the core model from the abstract or introduction? | local catalog |
| Are defined terms, abbreviations, and relationships introduced before use? | local catalog |
| What happens on navigation, page hide, restore, and discard? | local catalog |
| Does state leak across lifecycle transitions? | local catalog |
| Are error names and timing defined? | local catalog |
| Could errors become account, device, or permission oracles? | local catalog |
| How are unknown fields, versions, and extensions handled? | local catalog |
| Can future values be added compatibly? | local catalog |
| How do authors detect support? | local catalog |
| Does detection itself reveal high-entropy information? | local catalog |
| What implementation or incubation evidence supports the design? | local catalog |
| Is shipping pressure causing unresolved architectural questions to be skipped? | local catalog |
| Are names precise, non-misleading, and extensible? | local catalog |
| Are units and default values explicit? | local catalog |
| Can existing events, promises, permissions, Fetch, URL, or policy mechanisms represent this behavior? | local catalog |
| How does the feature interact with layout, painting, accessibility, and user preferences? | local catalog |
| Is the exact reviewed snapshot clear? | local catalog |
| Are self-review answers, changes since prior review, issue venue, and deadline available? | local catalog |
| What happens by default before author or user configuration? | local catalog |
| Is the least powerful behavior the default? | local catalog |
| Is the feature restricted to secure contexts? | local catalog |
| Is mixed-content or insecure-origin behavior defined? | local catalog |
| Can the design return only the user-selected item? | local catalog |
| Is enumeration needed before user intent? | local catalog |
| How does the feature interact with Fetch, redirects, caches, and service workers? | local catalog |
| What user action expresses intent? | local catalog |
| Can embedded or background contexts trigger the feature without a gesture? | local catalog |
| Do IDL types, defaults, exceptions, and promise behavior match platform conventions? | local catalog |
| Which globals expose the feature? | local catalog |
| Are background or service worker uses justified? | local catalog |

## harms

| Question | Source |
|---|---|
| Which stakeholders may experience an identifiable harm from this design? | local catalog |

## human-rights

| Question | Source |
|---|---|
| Which affected people and rights require investigation under RFC 9620? | [source](https://www.rfc-editor.org/rfc/rfc9620) |

## internationalization

| Question | Source |
|---|---|
| Which internationalization self-review questions apply? | local catalog |

## privacy

| Question | Source |
|---|---|
| Can relying parties test account existence? | local catalog |
| Are negative responses distinguishable before user mediation? | local catalog |
| Can the feature capture bystanders? | local catalog |
| Are indicators, minimization, or local processing available? | local catalog |
| Do any deliverables create privacy-sensitive capabilities or data processing? | local catalog |
| Does the charter route future privacy review to the right venue? | local catalog |
| Which contexts can observe the signal? | local catalog |
| Can cross-site correlation occur without user awareness? | local catalog |
| What data is exposed, to whom, and for what purpose? | local catalog |
| Can less precise or less persistent data satisfy the use case? | local catalog |
| Is full enumeration necessary? | local catalog |
| Are labels hidden until permission or selection? | local catalog |
| Can callers distinguish private state through error detail or timing? | local catalog |
| What new entropy does the feature expose? | local catalog |
| Can values be rounded, bucketed, or permission-gated? | local catalog |
| What precision is exposed? | local catalog |
| Can access continue in the background? | local catalog |
| Is approximate data sufficient? | local catalog |
| What metadata is observable to servers, intermediaries, or other origins? | local catalog |
| Can it be minimized or partitioned? | local catalog |
| Can network observers or origins correlate browsing activity through this feature? | local catalog |
| Is state partitioned by top-level site, origin, or another justified boundary? | local catalog |
| How is permission shown to users? | local catalog |
| How can users revoke or inspect grants? | local catalog |
| When does state expire? | local catalog |
| How can users clear it? | local catalog |
| Does clearing site data remove it? | local catalog |
| Does state persist in private browsing? | local catalog |
| Can sites detect private mode through feature behavior? | local catalog |
| Does the request link to privacy considerations and self-review answers? | local catalog |
| Are changes since prior review and the requested deadline clear? | local catalog |
| What physical-world data is exposed? | local catalog |
| Can precision, sampling, or scope be reduced? | local catalog |
| What boundary scopes the identifier? | local catalog |
| Can it rotate or be pairwise? | local catalog |
| Can users clear or revoke it? | local catalog |
| Can embedded contexts use the feature? | local catalog |
| What top-level user or site control applies? | local catalog |

## security

| Question | Source |
|---|---|
| What is being authenticated? | local catalog |
| What authority is granted, by whom, and for how long? | local catalog |
| What keys the cache? | local catalog |
| Can attackers poison shared or partitioned cache entries? | local catalog |
| Is integrity preserved? | local catalog |
| Who can delegate the capability? | local catalog |
| Can the delegate exceed the delegator's authority? | local catalog |
| Do any deliverables create security-sensitive capabilities or protocols? | local catalog |
| Does the charter route future security review to the right venue? | local catalog |
| What principal is the feature acting for? | local catalog |
| How is authority bound to the requester? | local catalog |
| Can one origin infer another origin's state through the feature? | local catalog |
| What happens when stronger behavior is unavailable? | local catalog |
| Can an attacker force weaker behavior? | local catalog |
| Can untrusted input be interpreted as code, URL, header, or markup? | local catalog |
| Are URL parsing and encoding rules explicit? | local catalog |
| What validation happens before processing? | local catalog |
| Are malformed, oversized, or adversarial inputs defined? | local catalog |
| How are keys generated, stored, exported, rotated, and destroyed? | local catalog |
| What randomness requirements apply? | local catalog |
| What parser, decoder, or native component processes the input? | local catalog |
| Is it sandboxed and validated? | local catalog |
| Is the message bound to origin, audience, and freshness? | local catalog |
| Can it be replayed or triggered cross-site? | local catalog |
| Which origin or site has authority? | local catalog |
| Can one origin observe or affect another? | local catalog |
| Can two implementations parse the same bytes differently? | local catalog |
| Is the signed or compared representation canonical? | local catalog |
| Are all entry points subject to the same permission and policy checks? | local catalog |
| Can workers or iframes bypass UI gating? | local catalog |
| Is this a powerful feature that needs an explicit permission gate? | local catalog |
| Does the specification define Permissions API integration or another platform-consistent permission model? | local catalog |
| What is the default permission state and fail-closed behavior before any grant? | local catalog |
| Are permission checks performed before each sensitive operation and after revocation? | local catalog |
| What happens if authority changes during an operation? | local catalog |
| Are state transitions atomic enough? | local catalog |
| What resource limits apply? | local catalog |
| Can attackers exhaust storage, CPU, network, or UI prompts? | local catalog |
| Does the request link to security considerations or threat analysis? | local catalog |
| Are known security-sensitive changes and the issue venue clear? | local catalog |
| Is access limited to secure contexts? | local catalog |
| Does the feature fail closed if transport or context is insecure? | local catalog |
| Can web content spoof or obscure the UI? | local catalog |
| Does the UI clearly identify the requesting origin and action? | local catalog |
| Does the specification define evidence-backed attack surface minimization behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed attack surface minimization behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed authentication behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed authentication behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed authority and capability delegation behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed authority and capability delegation behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed authorization behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed authorization behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed canonicalization behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed canonicalization behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed concurrency races and reentrancy behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed concurrency races and reentrancy behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed confidentiality and information disclosure behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed confidentiality and information disclosure behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed conformance and implementation variance behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed credential lifecycle behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed credential lifecycle behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed cross origin communication behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed cross origin communication behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed cryptography and randomness behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed cryptography and randomness behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed device sensor and native boundaries behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed device sensor and native boundaries behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed error channels and oracles behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed error channels and oracles behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed extensibility and unknown fields behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed extensibility and unknown fields behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed external dependency assumptions behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed freshness and anti replay behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed freshness and anti replay behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed input validation behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed input validation behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed integrity and authenticity behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed integrity and authenticity behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed key management and algorithm agility behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed key management and algorithm agility behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed lifecycle navigation and bfcache behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed lifecycle navigation and bfcache behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed media codecs and untrusted binary input behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed media codecs and untrusted binary input behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed observability audit and abuse detection behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed origin and site isolation behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed origin and site isolation behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed parsing and serialization behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed parsing and serialization behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed permission lifecycle behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed permission lifecycle behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed privacy security intersections behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed protocol negotiation versioning and downgrade behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed protocol negotiation versioning and downgrade behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed resource exhaustion and amplification behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed resource exhaustion and amplification behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed revocation recovery and rollback behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed safe defaults and fail closed behavior behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed script and code loading behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed script and code loading behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed secure context and transport behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed secure context and transport behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed state storage and cache behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed state storage and cache behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed timing and side channels behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed timing and side channels behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed url fetch and redirect handling behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed url fetch and redirect handling behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed user intent and trusted ui behavior with clear authority, boundary, and failure semantics? | local catalog |
| Does the specification define evidence-backed user intent and trusted ui behavior with clear authority, boundary, and failure semantics? | local catalog |
| How are replay, expiry, retry, clock skew, and cached state handled? | local catalog |
| What evidence allows independent detection, rejection, investigation, and accountability? | local catalog |
| Which representation is canonical for parsing, comparison, signing, caching, and display? | local catalog |
| Does every cross-origin response exposure require an explicit server opt-in? | local catalog |
| How does the feature compose with CSP, including redirects, inline content, and nested contexts? | local catalog |
| Which fields or events are strictly necessary, and how are optional disclosures suppressed? | local catalog |
| What trust, address, integrity, redirect, cache, and resource policy applies to every nested retrieval? | local catalog |
| What happens when validation, permission, retrieval, or policy evaluation fails? | local catalog |
| Is authenticated encrypted transport the default, with cleartext exceptions explicit and fail-closed? | local catalog |
| What is validated, when does validation occur, and does failure prevent side effects? | local catalog |
| What independent evidence establishes integrity, authenticity, and acceptable provenance? | local catalog |
| Can any insecure resource enter a secure context through direct load, redirect, fallback, or cache? | local catalog |
| Which data and operations cross an origin or site boundary, and what explicit gate applies? | local catalog |
| Which state is partitioned, by what key, and which observable exceptions remain? | local catalog |
| How are permission grant, denial, expiry, revocation, and delegation handled? | local catalog |
| What is the default allowlist and how is delegation constrained? | local catalog |
| What precision, frequency, partition, and composition bounds apply to observable output? | local catalog |
| Are authorization, address, and policy checks repeated after every redirect? | local catalog |
| Which resource limits apply recursively and how does exceeding one fail? | local catalog |
| What code or content is untrusted and which sandbox boundary contains it? | local catalog |
| Is the feature restricted to a secure context at every exposure point? | local catalog |
| Which security-relevant facts are presented in unspoofable user-agent UI? | local catalog |
| Which operations require fresh user intent and what common bound applies when activation is absent? | local catalog |
| Can a site reliably revoke local state and prevent still-running same-origin contexts from immediately recreating it? | [source](https://www.w3.org/TR/2017/WD-clear-site-data-20171130/#header) |
| Are credential collection, storage, and presentation origin-bound and subject to explicit mediation where silent access is inappropriate? | [source](https://www.w3.org/TR/2026/WD-credential-management-1-20260702/#algorithm-same-origin-with-ancestors) |
| Are key material, exportability, permitted operations, and algorithm normalization constrained to the minimum required capability? | [source](https://www.w3.org/TR/2025/WD-webcrypto-2-20250422/#x10-crypto-interface) |
| Can deployments restrict every new fetch or execution surface using an existing CSP directive or a defined integration point? | [source](https://www.w3.org/TR/2026/WD-CSP3-20260505/#csp-header) |
| Does the execution model avoid ambient string-to-code authority and make any nonce, hash, or delegated trust boundary explicit? | [source](https://www.w3.org/TR/2026/WD-CSP3-20260505/#script-src-inline) |
| Does the feature introduce embeddable privileged UI or documents that need ancestor restrictions or sandbox integration? | [source](https://www.w3.org/TR/2026/WD-CSP3-20260505/#directive-frame-ancestors) |
| Are report-only policies clearly non-enforcing, and can reports avoid leaking sensitive URLs or data? | [source](https://www.w3.org/TR/2026/WD-CSP3-20260505/#cspro-header) |
| Are session scope, refresh eligibility, challenge handling, key creation, and proof verification all origin-bound and fail-closed? | [source](https://www.w3.org/TR/2025/WD-dbsc-1-20250821/#framework-scope) |
| Can an embedder state minimum document behavior and reject a response that does not commit to compatible policy values? | [source](https://wicg.github.io/document-policy/#require-document-policy-http-header) |
| Can a server distinguish cross-site, navigation, subresource, and user-activated requests before performing a sensitive action? | [source](https://www.w3.org/TR/2025/WD-fetch-metadata-20250401/#framework) |
| Can the feature fetch or embed insecure resources from a secure context, and is every request classified for upgrade or blocking before use? | [source](https://www.w3.org/TR/2023/CRD-mixed-content-20230223/#upgrade-algorithm) |
| Has the feature completed the Permissions integration contract, including a stable name, descriptor semantics, and registry entry? | [source](https://www.w3.org/TR/2025/WD-permissions-20251006/#specifying-a-powerful-feature) |
| Does the feature's permission-state algorithm compose with secure-context and Permissions Policy checks before consulting stored grants? | [source](https://www.w3.org/TR/2025/WD-permissions-20251006/#reading-current-states) |
| Are grant lifetime, expiry, revocation, and dependent-resource cleanup explicit and proportionate to sensitivity? | [source](https://www.w3.org/TR/2025/WD-permissions-20251006/#specifying-a-powerful-feature) |
| Is the API a policy-controlled feature with a justified default allowlist, preferably no broader than the minimum required? | [source](https://www.w3.org/TR/2026/WD-permissions-policy-1-20260618/#features) |
| Does embedded use require explicit delegation, and can any descendant or response policy widen authority beyond its parent? | [source](https://www.w3.org/TR/2026/WD-permissions-policy-1-20260618/#inherited-policies) |
| Are enforcement, delegation, and reporting paths defined, and is report-only state kept non-authorizing? | [source](https://www.w3.org/TR/2026/WD-permissions-policy-1-20260618/#delivery) |
| Can API URLs contain identifiers or capabilities that would leak through referrers, and is an appropriate restrictive policy defined? | [source](https://www.w3.org/TR/2017/CR-referrer-policy-20170126/#algorithms) |
| Does every sensitive entry point use [SecureContext], or an equally explicit secure-context gate with a defined failure? | [source](https://www.w3.org/TR/2023/CRD-secure-contexts-20231110/#integration-idl) |
| Does the specification reuse the Secure Contexts trustworthiness algorithm and define a fail-closed result when it returns not trustworthy? | [source](https://www.w3.org/TR/2023/CRD-secure-contexts-20231110/#is-origin-trustworthy) |
| Can remotely hosted executable or security-sensitive resources carry integrity metadata, and does verification select the strongest recognized metadata? | [source](https://www.w3.org/TR/2026/WD-sri-2-20260320/#get-the-strongest-metadata) |
| Is the failure mode blocking for integrity mismatch, and can deployments require integrity metadata for the new resource type? | [source](https://www.w3.org/TR/2026/WD-sri-2-20260320/#handling-integrity-violations) |
| Does the API accept strings that become HTML, script, or script URLs, and if so can the sink require the correct Trusted Type? | [source](https://www.w3.org/TR/2026/WD-trusted-types-20260623/#injection-sinks) |
| Can a deployment enforce Trusted Types for the new sink and limit policy creation to reviewed policy names? | [source](https://www.w3.org/TR/2026/WD-trusted-types-20260623/#require-trusted-types-for-csp-directive) |
| Is any default-policy conversion narrow, auditable, and fail-closed on rejected input? | [source](https://www.w3.org/TR/2026/WD-trusted-types-20260623/#default-policy-hdr) |
| Does the feature respect the client upgrade state before request dispatch, including nested contexts and WebSockets where applicable? | [source](https://www.w3.org/TR/2015/CR-upgrade-insecure-requests-20151008/#upgrading) |
| Is discovery bound to the account origin and secure transport, with redirect behavior constrained and handled explicitly? | [source](https://www.w3.org/TR/2024/WD-change-password-url-20240603/#semantics) |
| Is endpoint discovery same-RP, HTTPS-only, non-redirecting, and strict about response status and media type? | [source](https://www.w3.org/TR/2026/WD-passkey-endpoints-1-20260114/#semantics) |
| Does the target preserve or appropriately reuse HttpOnly script-visibility filter? | [source](https://cookiestore.spec.whatwg.org/#cookie-concept) |
| Does the target preserve or appropriately reuse Reserved secure cookie-prefix guards? | [source](https://cookiestore.spec.whatwg.org/#set-cookie-algorithm) |
| Does the target preserve or appropriately reuse Secure-context interface exposure? | [source](https://cookiestore.spec.whatwg.org/#cookiestore) |
| Does the target preserve or appropriately reuse Secure-only cookie writes? | [source](https://cookiestore.spec.whatwg.org/#secure-cookies) |
| Does the target preserve or appropriately reuse Trusted Types validation for attribute mutation? | [source](https://dom.spec.whatwg.org/#interface-element) |
| Does the target preserve or appropriately reuse Illegal multibyte sequence ASCII-unmasking rule? | [source](https://encoding.spec.whatwg.org/#security-background) |
| Does the target preserve or appropriately reuse Replacement encoding for unsafe labels? | [source](https://encoding.spec.whatwg.org/#replacement) |
| Does the target preserve or appropriately reuse Cross-Origin-Resource-Policy response gate? | [source](https://fetch.spec.whatwg.org/#cross-origin-resource-policy-header) |
| Does the target preserve or appropriately reuse Credential-aware CORS wildcard restriction? | [source](https://fetch.spec.whatwg.org/#cors-check) |
| Does the target preserve or appropriately reuse CORS cross-origin read authorization? | [source](https://fetch.spec.whatwg.org/#http-cors-protocol) |
| Does the target preserve or appropriately reuse Cross-origin redirect credential stripping and rejection? | [source](https://fetch.spec.whatwg.org/#http-redirect-fetch) |
| Does the target preserve or appropriately reuse Filtered response boundary? | [source](https://fetch.spec.whatwg.org/#concept-filtered-response) |
| Does the target preserve or appropriately reuse Forbidden request-header guard? | [source](https://fetch.spec.whatwg.org/#forbidden-request-header) |
| Does the target preserve or appropriately reuse Same-origin handle deserialization guard? | [source](https://fs.spec.whatwg.org/#api-filesystemhandle) |
| Does the target preserve or appropriately reuse Default-denied file-system entry access? | [source](https://fs.spec.whatwg.org/#concepts) |
| Does the target preserve or appropriately reuse Origin-partitioned bucket file system? | [source](https://fs.spec.whatwg.org/#sandboxed-filesystem) |
| Does the target preserve or appropriately reuse Fullscreen awareness and reliable exit? | [source](https://fullscreen.spec.whatwg.org/#security-and-privacy-considerations) |
| Does the target preserve or appropriately reuse Fullscreen Permissions Policy? | [source](https://fullscreen.spec.whatwg.org/#permissions-policy-integration) |
| Does the target preserve or appropriately reuse Transient-activation fullscreen gate? | [source](https://fullscreen.spec.whatwg.org/#dom-element-requestfullscreen) |
| Does the target preserve or appropriately reuse Canvas origin-clean tainting? | [source](https://html.spec.whatwg.org/#security-with-canvas-elements) |
| Does the target preserve or appropriately reuse Cross-Origin-Embedder-Policy resource isolation? | [source](https://html.spec.whatwg.org/#coep) |
| Does the target preserve or appropriately reuse Cross-Origin-Opener-Policy browsing-context isolation? | [source](https://html.spec.whatwg.org/#cross-origin-opener-policies) |
| Does the target preserve or appropriately reuse Restricted meta-delivered Content Security Policy? | [source](https://html.spec.whatwg.org/#pragma-directives) |
| Does the target preserve or appropriately reuse Origin as the primary web security boundary? | [source](https://html.spec.whatwg.org/#writing-secure-applications-with-html) |
| Does the target preserve or appropriately reuse Sandboxing flag set? | [source](https://html.spec.whatwg.org/#sandboxing) |
| Does the target preserve or appropriately reuse Transient and sticky user activation state? | [source](https://html.spec.whatwg.org/#tracking-user-activation) |
| Does the target preserve or appropriately reuse No scriptable MIME promotion from mislabeled binary data? | [source](https://mimesniff.spec.whatwg.org/#sniffing-a-mislabeled-binary-resource) |
| Does the target preserve or appropriately reuse No-sniff supplied-type preservation? | [source](https://mimesniff.spec.whatwg.org/#determining-the-computed-mime-type-of-a-resource) |
| Does the target preserve or appropriately reuse Notifications permission gate? | [source](https://notifications.spec.whatwg.org/#permissions-integration) |
| Does the target preserve or appropriately reuse Storage-key segmentation? | [source](https://storage.spec.whatwg.org/#storage-keys) |
| Does the target preserve or appropriately reuse Persistent-storage permission? | [source](https://storage.spec.whatwg.org/#persistence) |
| Does the target preserve or appropriately reuse URL credential validation signal? | [source](https://url.spec.whatwg.org/#url-parsing) |
| Does the target preserve or appropriately reuse Origin-based security decisions? | [source](https://url.spec.whatwg.org/#warning-avoid-psl) |
| Does the target preserve or appropriately reuse Documented regexp-group restriction hook? | [source](https://urlpattern.spec.whatwg.org/#other-specs) |
| Does the target preserve or appropriately reuse [CrossOriginIsolated] exposure condition? | [source](https://webidl.spec.whatwg.org/#CrossOriginIsolated) |
| Does the target preserve or appropriately reuse Sensitive exception-message redaction requirement? | [source](https://webidl.spec.whatwg.org/#js-creating-throwing-exceptions) |
| Does the target preserve or appropriately reuse Global exposure allowlist? | [source](https://webidl.spec.whatwg.org/#Exposed) |
| Does the target preserve or appropriately reuse [SecureContext] exposure condition? | [source](https://webidl.spec.whatwg.org/#SecureContext) |
| Does the target preserve or appropriately reuse Restricted WebSocket opening handshake? | [source](https://websockets.spec.whatwg.org/#websocket-opening-handshake) |
| Does the target preserve or appropriately reuse WebSocket URL and subprotocol validation? | [source](https://websockets.spec.whatwg.org/#interface-definition) |
| Does the target preserve or appropriately reuse Cross-origin credential opt-in? | [source](https://xhr.spec.whatwg.org/#the-withcredentials-attribute) |
| Does the target preserve or appropriately reuse Forbidden request-header guard? | [source](https://xhr.spec.whatwg.org/#the-setrequestheader()-method) |
| Does the target preserve or appropriately reuse Forbidden HTTP method guard? | [source](https://xhr.spec.whatwg.org/#the-open()-method) |

